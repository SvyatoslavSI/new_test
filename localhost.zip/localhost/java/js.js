function valid()
	{
		let check = false;
		let remail = /^[\w-\.]+@[\w-]+\.[a-z]{2,4}$/i;
		let repass = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
		let myMail = document.getElementById('inlineFormInputGroupUsername2').value;
		let myPass = document.getElementById('inlineFormInputName2').value;
		let valid = remail.test(myMail);
		if (!valid) {alert("Почта указанна не верно!");check=true;}
		valid = repass.test(myPass);
		if (!valid) {alert("Пароль минимум восемь символов, по крайней мере, одна буква и одна цифра");check=true;}	
		return check;
	}