<?php
//объявляем файлы конфигурации
$FileAccess='conf';
$ConfAccess=file_get_contents($FileAccess);
global $conf;
$conf=array(json_decode($ConfAccess,true))[0];

//создаем сессию для авторитизации
session_start();
if(empty($_SESSION['status']))$_SESSION['status'] = "unreg";

//подключаемся к бд
if(!$MySqli=mysqli_connect($conf["host"],$conf["user"],$conf["pass"],$conf["db"]))
err("<strong>Oh snap!</strong> You dont connection for DB MySQL!");

if($_SESSION['status'] == "unreg")
{
if(isset($_POST["well"])) 
{
	if(!empty($_POST["email"])and !empty($_POST["password"]))
	{
		if(chekdate($_POST["email"],$_POST["password"])) $_SESSION['status']="well";
		else err("<strong>Oh snap!</strong> Неверные данные пользователя1!");

	}
}
elseif(isset($_POST["reg"]))
{
	if(!empty($_POST["email"])and !empty($_POST["password"]))
	{
		if(chekdate($_POST["email"],$_POST["password"])) $_SESSION['status'] = "reg";
		else err("<strong>Oh snap!</strong> Неверные данные пользователя2!");
	}
}
}


if(isset($_POST["exit"])) $_SESSION['status'] = "unreg";


	 //проверяем состояния нажатых кнопок
	 switch ($_SESSION['status'])
	 {		 
	 case "well": {if (is_user($_POST["email"], $_POST["password"], $MySqli)) {$_SESSION['status']="registration"; break;} else {$_SESSION['status']="unreg"; err("Пользователь не найден");break;}}
	 case "reg": {if(is_user_free($_POST["email"],$MySqli)){RegNewUser($_POST["email"], $_POST["password"], $MySqli); $_SESSION['status']="registration";break;} else {$_SESSION['status']="unreg"; err("Пользователь занят");break;}}
	 case "exit":{$_SESSION['status']="unreg"; break;}
	 default :break;
	 }	 
//проверка корректнрости данных
function chekdate($log,$pass)
{
	$regmail='/[0-9a-z]+@[a-z]/';
	$regpass='/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/';
if (preg_match($regmail, $log, $match1) and preg_match($regpass, $pass, $match2)) return true;
else return false;	
}
//вывод ошибок
function err($str)
{
echo '<div class="alert alert-danger" role="alert">'.$str.'</div>';
}
//проверка наличия пользователя
function is_user($log, $pass, $mysql)
{
//$hashpass=password_hash((string)$pass, PASSWORD_DEFAULT);
$qr="SELECT `id` FROM `users` WHERE `email` = '$log' AND `pass` = '$pass'";
$result=$mysql->query($qr);
$row = $result->fetch_assoc();
if(empty($row["id"])) return false;
else  return true;
return false;
}
//проверка отсутствия пользователя
function is_user_free($log, $mysql)
{
//$hashpass=password_hash((string)$pass, PASSWORD_DEFAULT);
$qr="SELECT `id` FROM `users` WHERE `email` = '$log'";
$result=$mysql->query($qr);
$row = $result->fetch_assoc();
if(empty($row["id"])) return true;
else  return false;
return false;
}

//регистрация нового пользователя
function RegNewUser($log, $pass, $mysql)
{
	$qr="INSERT INTO `users` (`email`,`pass`) VALUES ('$log','$pass') ON DUPLICATE KEY UPDATE `email` ='$log'";
	
	echo $qr;
	$result=$mysql->query($qr);
}

mysqli_close($MySqli);



require_once("html/header.php");//подключаем шапку
if($_SESSION['status']=="registration")
	require_once("html/access.php");//подключаем то что разрешено доступом
else require_once("html/error.php");//сообщение для незарегистрированных пользователей

require_once("html/footer.php");//подключаем футер
?>
