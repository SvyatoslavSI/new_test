<?php 
echo '<html>
<head>
    <title>TestReg</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
<script src="/java/js.js"></script>
</head>
<body>
	<header class="navbar navbar-expand-md navbar-light sticky-top " style="background-color: #e3f2fd;"  >
	<span class= "conteiner-fluid">
	<a href="#" class="navar-brad"><img src="img/logo.png" style="width: 100;"></a>
	</span>
	
	<!--<form style="width:250px; margin: 0 auto; ">
  <span class="form-group">
   <!-- <label for="formGroupExampleInput">Em@il</label>-->
   <!-- <input type="email" class="form-control" id="formGroupExampleInput" placeholder="Введите ем@ил">
  </span>
  <div class="form-group">
    <!--<label for="formGroupExampleInput2">Another label</label>-->
   <!-- <input type="password" class="form-control" id="formGroupExampleInput2" placeholder="Введите пароль">
  </div>
</form>-->
<form class="form-inline" style="width:250px; margin: 0 auto; " method="POST">';
if($_SESSION['status'] == "unreg")
	echo '
<div>
  <label class="sr-only" for="inlineFormInputGroupUsername2">Username</label>
  <div class="input-group mb-2 mr-sm-2">
    <div class="input-group-prepend">
      <div class="input-group-text">@</div>
    </div>
    <input type="email" class="form-control" id="inlineFormInputGroupUsername2" placeholder="Ем@ил" name="email">
  </div>
  
<label class="sr-only" for="inlineFormInputName2">Name</label>
  <input type="password" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" placeholder="Пароль" name="password" minlength="8">
 </div> 
  <!--<div class="form-check mb-2 mr-sm-2">
    <input class="form-check-input" type="checkbox" id="inlineFormCheck">
    <label class="form-check-label" for="inlineFormCheck">
      Remember me
    </label>
  </div>-->
<div>
  <button type="submit" class="btn btn-primary mb-2" id="well" name="well">Войти</button>
  <button type="submit" class="btn btn-primary mb-2" id="reg" name="reg">Зарегистрироваться</button>
  </div> ';
  if($_SESSION['status'] == "registration") echo '
  <div>
  <button type="submit" class="btn btn-primary mb-2" id="exit" name="exit">Выйти</button>
 </div>';
 echo'
</form>
	</header>';