<?php echo '<footer  class="navbar  navbar-light fixed-bottom " style="background-color: #e3f2fd;">
	<span class="badge badge-info">Open server</span>
	<span class="badge badge-info">MySQL</span>
	<span class="badge badge-info">HTML</span>
	<span class="badge badge-info">CSS</span>
	<span class="badge badge-info">JavaScrypt</span>
	<span class="badge badge-info">Ajax</span>
	<span class="badge badge-info">Session</span>
	<span class="badge badge-info">PHP</span>
	<span class="badge badge-info">Git</span>
	<span class="badge badge-info">Github</span>
	<span class="badge badge-warning">By Svyatoslav 2024</span>
	</footer>
	
	<script>
	document.querySelector("#well").onclick = function(event){ if(valid()) event.preventDefault();} 
	document.querySelector("#reg").onclick = function(event){ if(valid()) event.preventDefault();}
	</script>
</body>
</html>';