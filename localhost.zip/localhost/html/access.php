<?php echo '<content>
<div class="alert alert-success" role="alert">
    <strong>Well done!</strong> You successfully read this
    important alert message.
</div>';
//инцианизация апи
$api=curl_init();
$url="https://www.boredapi.com/api/activity";
curl_setopt($api, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($api, CURLOPT_URL, $url);
$response=curl_exec($api);
curl_close($api);


echo '
<div class="jumbotron" style="margin: 0 auto; text-align: center;">
  <h1 class="display-3">';
  $content = json_decode($response,true);

 echo $content["activity"];
  
echo '  </h1>
  <p class="lead">Эти данные получены из api сайта '.$url.' </p>
  <hr class="my-2">
</div>
	</content>';