<?php echo '<content>
	<center><img src="img/forbidden.jpg" class="img-thumbnail"></center>
	</content>
	<content>';